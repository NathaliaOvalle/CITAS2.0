<!DOCTYPE html>
<html>
<head>
    <title>Consulta de Citas Médicas</title>
</head>
<body>
    <h2>Consulta de Citas Médicas</h2>
    <table>
        <thead>
            <tr>
                <th>ID cita</th>
                <th>Fecha</th>
                <th>Paciente</th>
                <th>Médico</th>
            </tr>
        </thead>
        <tbody>
            <!-- Aquí se mostrarán las filas de las citas médicas -->
            <tr>
                <td>1</td>
                <td>2023-05-26</td>
                <td>Juan Pérez</td>
                <td>Dr. García</td>
            </tr>
            <tr>
                <td>2</td>
                <td>2023-05-27</td>
                <td>María López</td>
                <td>Dr. Rodríguez</td>
            </tr>
            <!-- Puedes generar estas filas dinámicamente en PHP -->
        </tbody>
    </table>
</body>
</html>
