<!DOCTYPE html>
<html>
<head>
    <title>LoginCitas</title>
</head>
<body>
    <h2>Ingresar</h2>
    <form method="POST" action="validar_login.php">
        <label>Nombre:</label>
        <input type="text" name="usuario" required><br>

        <label>Apellido:</label>
        <input type="password" name="contrasena" required><br>

        <label>Tipo de Documento:</label>
        <input type="text" name="usuario" required><br>

        <label>Numero de Documento:</label>
        <input type="text" name="usuario" required><br>

        <label>Telefono:</label>
        <input type="text" name="usuario" required><br>
        
        <input type="submit" value="Iniciar sesión">
    </form>
</body>
</html>
